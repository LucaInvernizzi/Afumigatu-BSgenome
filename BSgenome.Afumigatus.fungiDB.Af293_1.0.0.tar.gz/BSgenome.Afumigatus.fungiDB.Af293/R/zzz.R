###
###

.pkgname <- "BSgenome.Afumigatus.fungiDB.Af293"

.seqnames <- c("Chr1_A_fumigatus_Af293","Chr2_A_fumigatus_Af293","Chr3_A_fumigatus_Af293","Chr4_A_fumigatus_Af293","Chr5_A_fumigatus_Af293","Chr6_A_fumigatus_Af293","Chr7_A_fumigatus_Af293","Chr8_A_fumigatus_Af293", "mito_A_fumigatus_Af293")

.circ_seqs <- "mito_A_fumigatus_Af293"

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Aspergillus fumigatus",
        common_name="A. fumigatus",
        genome="ASM265v1",
        provider="fungiDB",
        release_date="2005/06",
        source_url="https://fungidb.org/fungidb/app/record/organism/NCBITAXON_330879",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Afumigatus"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

